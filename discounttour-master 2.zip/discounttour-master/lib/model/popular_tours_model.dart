class PopularTourModel {
  String imgUrl;
  String title;
  String desc;
  String price;
  double rating;
}
