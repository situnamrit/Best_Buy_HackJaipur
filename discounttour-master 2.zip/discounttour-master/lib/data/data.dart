import 'package:discounttour/model/country_model.dart';
import 'package:discounttour/model/popular_tours_model.dart';

List<CountryModel> getCountrys() {
  List<CountryModel> country = new List();
  CountryModel countryModel = new CountryModel();

//1
  countryModel.countryName = "City Super Bazaar";
  countryModel.label = "New";
  countryModel.noOfTours = 18;
  countryModel.rating = 4.5;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/868110/pexels-photo-868110.jpeg?cs=srgb&dl=vegetables-stall-868110.jpg&fm=jpg";
  country.add(countryModel);
  countryModel = new CountryModel();

  //1
  countryModel.countryName = "Koel Bazaar";
  countryModel.label = "Sale";
  countryModel.noOfTours = 12;
  countryModel.rating = 4.3;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/4054850/pexels-photo-4054850.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";
  country.add(countryModel);
  countryModel = new CountryModel();

  //1
  countryModel.countryName = "Gross Store";
  countryModel.label = "New";
  countryModel.noOfTours = 18;
  countryModel.rating = 4.5;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/2383315/pexels-photo-2383315.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  country.add(countryModel);
  countryModel = new CountryModel();

  //1
  countryModel.countryName = "MyGrocery";
  countryModel.label = "New";
  countryModel.noOfTours = 18;
  countryModel.rating = 4.5;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/1005638/pexels-photo-1005638.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  country.add(countryModel);
  countryModel = new CountryModel();

  //1
  countryModel.countryName = "Mom's Magic";
  countryModel.label = "New";
  countryModel.noOfTours = 18;
  countryModel.rating = 4.5;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/2079438/pexels-photo-2079438.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  country.add(countryModel);
  countryModel = new CountryModel();

  //1
  countryModel.countryName = "Friend's Store";
  countryModel.label = "New";
  countryModel.noOfTours = 18;
  countryModel.rating = 4.5;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/2292919/pexels-photo-2292919.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  country.add(countryModel);
  countryModel = new CountryModel();

  //1
  countryModel.countryName = "Needs";
  countryModel.label = "New";
  countryModel.noOfTours = 18;
  countryModel.rating = 4.5;
  countryModel.imgUrl =
      "https://images.pexels.com/photos/264537/pexels-photo-264537.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  country.add(countryModel);
  countryModel = new CountryModel();

  return country;
}

List<PopularTourModel> getPopularTours() {
  List<PopularTourModel> popularTourModels = new List();
  PopularTourModel popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/65438/pexels-photo-65438.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "City Super Bazaar";
  popularTourModel.desc = "Free DoorStep Delivery";
  popularTourModel.price = "2 slots";
  popularTourModel.rating = 4.0;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/696205/pexels-photo-696205.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "Koel Bazaar";
  popularTourModel.desc = "Shop Opens 10 AM";
  popularTourModel.price = "45 slots";
  popularTourModel.rating = 4.5;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/880463/pexels-photo-880463.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "Friends Store";
  popularTourModel.desc = "Seperate Counters";
  popularTourModel.price = "100 slots";
  popularTourModel.rating = 4.2;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/880463/pexels-photo-880463.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "Needs";
  popularTourModel.desc = "List the items";
  popularTourModel.price = "98 slots";
  popularTourModel.rating = 4.0;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/1565982/pexels-photo-1565982.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "Moms Magic";
  popularTourModel.desc = "Sanitization  HandWash";
  popularTourModel.price = "200+ slots";
  popularTourModel.rating = 4.0;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "Happy Shopping";
  popularTourModel.desc = "Delivery Trucks";
  popularTourModel.price = "15 Slots";
  popularTourModel.rating = 4.0;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/2199190/pexels-photo-2199190.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "New Gross";
  popularTourModel.desc = "Fresh Veggies from Farms";
  popularTourModel.price = "No Slots only Online";
  popularTourModel.rating = 4.0;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

//1
  popularTourModel.imgUrl =
      "https://images.pexels.com/photos/709838/pexels-photo-709838.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500";
  popularTourModel.title = "Veggies";
  popularTourModel.desc = "Only packed foods available";
  popularTourModel.price = "5 slots";
  popularTourModel.rating = 4.0;
  popularTourModels.add(popularTourModel);
  popularTourModel = new PopularTourModel();

  return popularTourModels;
}
